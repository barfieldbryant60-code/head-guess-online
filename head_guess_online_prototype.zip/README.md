# Head Guess Online Prototype

A two-player online hidden-word guessing game.

## Run locally

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:
   npm install
   npm start
4. Open http://localhost:3000

For two devices on the same Wi-Fi, use your computer's local IP address, for example:
http://192.168.1.20:3000

## Deploy online

This project is ready for a Node/WebSocket host such as Render, Railway, or another Node hosting service.

Build/start command:
npm start

The host must support WebSockets.

## Game rules

Each player enters a secret word for the OTHER player's card. The server stores the words but never sends a player's own secret back to that player. Players alternate guesses. Correct guess wins; wrong guess passes the turn.

For a production version, add authentication, persistent rooms, reconnect handling, moderation, and stronger server-side validation.
