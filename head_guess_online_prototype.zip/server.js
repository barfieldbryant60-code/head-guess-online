const express = require("express");
const http = require("http");
const { WebSocketServer } = require("ws");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
const rooms = new Map();

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_, res) => res.json({ok:true}));

function send(ws, data) {
  if (ws.readyState === 1) ws.send(JSON.stringify(data));
}
function broadcast(room) {
  for (const p of room.players) send(p.ws, {
    type:"state",
    players: room.players.map((p,i)=>({name:p.name, index:i})),
    turn: room.turn,
    phase: room.phase,
    winner: room.winner
  });
}
function roomStateFor(room, index) {
  const own = room.players[index];
  const other = room.players[1-index];
  return {
    type:"game",
    me:index,
    players:room.players.map(p=>p.name),
    turn:room.turn,
    phase:room.phase,
    // Never send a player's own secret back to them.
    otherHasWord: !!other?.secret,
    myWordSet: !!own?.secret,
    winner:room.winner
  };
}

wss.on("connection", ws => {
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    if (msg.type === "join") {
      const code = String(msg.room || "").trim().toUpperCase();
      const name = String(msg.name || "Player").trim().slice(0,24) || "Player";
      if (!code) return send(ws,{type:"error",message:"Enter a room code."});

      let room = rooms.get(code);
      if (!room) {
        room = {players:[], turn:0, phase:"setup", winner:null};
        rooms.set(code, room);
      }
      if (room.players.length >= 2) return send(ws,{type:"error",message:"That room is full."});

      const player = {ws,name,secret:null};
      room.players.push(player);
      ws.room = code;
      ws.index = room.players.length-1;

      send(ws,{type:"joined",index:ws.index,room:code});
      if (room.players.length === 2) {
        room.phase="secrets";
        room.players.forEach((p,i)=>send(p, roomStateFor(room,i)));
      } else {
        send(ws, roomStateFor(room,ws.index));
      }
      broadcast(room);
    }

    const code = ws.room;
    if (!code) return;
    const room = rooms.get(code);
    if (!room) return;
    const i = ws.index;

    if (msg.type === "secret" && room.phase === "secrets") {
      const word = String(msg.word || "").trim().toLowerCase();
      if (!word || word.length > 40) return send(ws,{type:"error",message:"Enter a word up to 40 characters."});
      // Your word becomes the OTHER player's hidden word.
      room.players[1-i].secret = word;
      room.players.forEach((p,j)=>send(p, roomStateFor(room,j)));
      if (room.players.every(p=>p.secret)) {
        room.phase="playing";
        room.turn=0;
        room.players.forEach((p,j)=>send(p, roomStateFor(room,j)));
      }
    }

    if (msg.type === "guess" && room.phase === "playing") {
      if (i !== room.turn || room.winner !== null) return;
      const guess = String(msg.guess || "").trim().toLowerCase();
      const target = room.players[i].secret;
      if (!guess) return;

      if (guess === target) {
        room.winner=i;
        room.phase="finished";
      } else {
        room.turn=1-i;
      }
      room.players.forEach((p,j)=>send(p, roomStateFor(room,j)));
    }

    if (msg.type === "restart") {
      room.players.forEach(p=>p.secret=null);
      room.turn=0; room.phase="secrets"; room.winner=null;
      room.players.forEach((p,j)=>send(p, roomStateFor(room,j)));
    }
  });

  ws.on("close", () => {
    const code=ws.room, room=rooms.get(code);
    if (!room) return;
    room.players = room.players.filter(p=>p.ws!==ws);
    if (room.players.length===0) rooms.delete(code);
    else {
      room.phase="waiting"; room.winner=null;
      room.players[0].index=0;
      send(room.players[0].ws,{type:"error",message:"The other player disconnected. Waiting for a new player."});
      broadcast(room);
    }
  });
});

const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log("Head Guess running on port "+PORT));
